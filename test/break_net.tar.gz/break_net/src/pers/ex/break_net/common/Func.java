package pers.ex.break_net.common;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

import com.google.gson.Gson;

public class Func {
	private final static SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
	public final static Pattern ipPattern = Pattern.compile("((?:(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|[01]?\\d?\\d))");
	
	public static String getTime() {
		return ft.format(new Date())+":    ";
	}
	
	public static String readToString(File file) {  
        String encoding = "UTF-8";  
        Long filelength = file.length();  
        byte[] filecontent = new byte[filelength.intValue()];  
        try {  
            FileInputStream in = new FileInputStream(file);  
            in.read(filecontent);  
            in.close();  
        } catch (FileNotFoundException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        try {  
            return new String(filecontent, encoding);  
        } catch (UnsupportedEncodingException e) {  
            System.err.println("The OS does not support " + encoding);  
            e.printStackTrace();  
            return null;  
        }  
    }
	
	public static boolean check(String addr,String ipFilePath) {
		Matcher m = ipPattern.matcher(addr);
		m.find();
		addr=m.group(0);
		
		File ipFile=new File(ipFilePath);
		String ipStr = Func.readToString(ipFile);
		List<String> ipList=new Gson().fromJson(ipStr, List.class);
		if(ipList.indexOf(addr)==-1) {
			return false;
		}else {
			return true;
		}
	}
}


