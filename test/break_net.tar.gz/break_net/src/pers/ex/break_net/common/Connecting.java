package pers.ex.break_net.common;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;

public class Connecting extends Thread{
	private static int amount=0;
	private Thread thread1;
	private Thread thread2;
	
	private int type;
	
	private Socket remote;
	private Socket inner;
	
	public Connecting(Socket remote,Socket inner) {
		this.remote=remote;
		this.inner=inner;
		type=0;
		amount++;
	}
	
	public void run() {
		byte[] buf=new byte[0x1000];
		
		if(type==0) {
			type=1;
			DataInputStream in=null;
			DataOutputStream out=null;
			
			try {
				in = new DataInputStream(remote.getInputStream());
				out = new DataOutputStream(inner.getOutputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				type=-1;
			}
			
			while(true) {
				if(!(remote.isClosed()==false && inner.isClosed()==false && type!=-1)) {
					type=-1;
					try {
						inner.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					System.out.println(Func.getTime()+"Disconnected from host address:  " + remote.getRemoteSocketAddress());
					break;
				}
				
				
				try {
					int length = in.read(buf);
					
					if(length!=-1) {
						out.write(buf, 0, length);
					}else {
						type=-1;
					}
				} catch (SocketTimeoutException e) {
					continue;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					type=-1;
				}
			}
		}else if(type==1) {
			type=2;
			
			DataInputStream in=null;
			DataOutputStream out=null;
			
			try {
				in = new DataInputStream(inner.getInputStream());
				out = new DataOutputStream(remote.getOutputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				type=-1;
			}
			
			while(true) {
				if(!(remote.isClosed()==false && inner.isClosed()==false && type!=-1)) {
					type=-1;
					try {
						inner.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				}
				
				try {
					int length = in.read(buf);
					
					if(length!=-1) {
						out.write(buf, 0, length);
					}else {
						type=-1;
					}
				} catch (SocketException e) {
					;
				} catch (SocketTimeoutException e) {
					continue;
				}catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					type=-1;
				}
			}
		}
	}
	
	public void start() {
		try {
			inner.setSoTimeout(1000);
			remote.setSoTimeout(1000);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(thread1==null) {
			thread1=new Thread(this);
			thread1.start();
		}
		
		if(thread2==null) {
			thread2=new Thread(this);
			thread2.start();
		}
	}
}