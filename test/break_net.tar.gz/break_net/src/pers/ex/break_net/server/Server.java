package pers.ex.break_net.server;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import pers.ex.break_net.common.*;

public class Server {
	public Object[][] map;
	public String ipFilePath;
	private int bindPort;
	private ServerSocket innerSocket;
	public Socket inner;
	public DataOutputStream innerOut ;
	public DataInputStream innerIn ;
	
	public Map<Integer,ServerSocket> remoteSocket;
	public Map<Integer,Socket> remote;
	
	public ReentrantLock lock;
	
	
	public Server(Object[][] map,int port,String ipPath) {
		this.map=map;
		this.bindPort=port;
		ipFilePath=ipPath;
		lock=new ReentrantLock();
		
		remoteSocket=new HashMap();
	}
	
	private Socket waitForConnect(ServerSocket in) {
		Socket s;
		while(true){
			try {
				s = in.accept();
				if(Func.check(s.getRemoteSocketAddress().toString(), ipFilePath)==true) {
					innerOut = new DataOutputStream(s.getOutputStream());
					innerIn = new DataInputStream(s.getInputStream());
					
					s.setSoTimeout(5000);
					break;
				}
				
				System.out.println(Func.getTime()+"Refuse the host address "+s.getRemoteSocketAddress().toString()+" connect to port "+bindPort);
				s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.err.println(e);
			}
		}
		
		System.out.println(Func.getTime()+"Connected to inner machine:  " + s.getRemoteSocketAddress());
		return s;
	}
	
	public void startListen(){
		try {
			this.innerSocket=new ServerSocket(bindPort);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println(Func.getTime()+"Wait for inner machine connection");
		inner = waitForConnect(innerSocket);
		
		System.out.println(Func.getTime()+"Inner host address:  " + inner.getRemoteSocketAddress());
		
		try {
			for(int i=0;i<map.length;i++) {
				int t_port=(new Double((double)map[i][0])).intValue();
				remoteSocket.put(t_port, new ServerSocket(t_port));
				System.out.println(Func.getTime()+"Start listen port "+t_port);
				
				Listen l=new Listen(this,t_port);
				l.start();
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		
		while (true) {
			if(inner!=null && inner.isClosed()==false) {
				try {
					innerOut.writeByte(22);
					byte b=innerIn.readByte();
					
					if(b==33) {
						TimeUnit.SECONDS.sleep(5);
						continue;
					}else {
						inner.close();
					}
				} catch (EOFException e) {
					System.err.println(Func.getTime()+"Disonnected from inner machine:  "+inner.getRemoteSocketAddress());
					try {
						inner.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}catch (SocketException e) {
					e.printStackTrace();
					System.err.println(Func.getTime()+"Disonnected from inner machine:  "+inner.getRemoteSocketAddress());
					try {
						inner.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}catch (SocketTimeoutException e) {
					System.err.println(Func.getTime()+"Inner machine timeout.");
					System.err.println(Func.getTime()+"Disonnected from inner machine:  "+inner.getRemoteSocketAddress());
					try {
						inner.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				continue;
			}
			
			lock.lock();
			try {
				if(inner!=null && inner.isClosed()==false ) {
					inner.close();
				}
				
				System.out.println(Func.getTime()+"Prepare a new connection");
				inner=waitForConnect(innerSocket);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			lock.unlock();
			
		}
	}
}

class Listen extends Thread{
	
	private Thread thread;
	private Server server;
	private int port;
	private ReentrantLock lock;
	
	public Listen(Server s,int port) {
		server=s;
		this.port=port;
		this.lock=s.lock;
	}
	
	public void run() {
		
			
			
			Socket s;
			while(true){
				lock.lock();
				lock.unlock();
				
				try {
					s = server.remoteSocket.get(port).accept();
					if(Func.check(s.getRemoteSocketAddress().toString(), server.ipFilePath)==false) {
						System.out.println(Func.getTime()+"Refuse the host address "+s.getRemoteSocketAddress().toString()+" to connect to port "+port);
						s.close();
						continue;
					}else {
						System.out.println(Func.getTime()+"Received a valid host address "+s.getRemoteSocketAddress().toString()+" to connect to port "+port);
					}
					
					if(server.inner==null || server.inner.isClosed()==true) {
						System.out.println(Func.getTime()+"There is no connection with inner machine");
						continue;
					}
					
					DataOutputStream out = new DataOutputStream(server.inner.getOutputStream());
					
					String mapStr="";
					Object[][] temp=server.map;
					for (int i=0;i<temp.length;i++) {
						if((new Double((double)temp[i][0])).intValue()==port) {
							mapStr=temp[i][1].toString()+"\0";	//Overwrite the original memory,Error prevention
						}
					}
					out.write(mapStr.getBytes(), 0, mapStr.length());
					
					DataInputStream in = new DataInputStream(server.inner.getInputStream());
					byte[] b_str=new byte[128];
					in.read(b_str);//
					
					if(b_str.toString().equals("my_breaksucceedmy_break")) {
						s.close();
						continue;
					}
					System.out.println(Func.getTime()+"Established connection from host address:  " + s.getRemoteSocketAddress()+" to "+mapStr.replace("\0", ""));
					
					Connecting c=new Connecting(s,server.inner);
					server.inner=null;
					c.start();
					
					
					
				} catch(SocketException e) {
					if(e.getMessage().indexOf("Socket is closed")==-1) {
						
					}
				}catch (IOException e) {
				
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					TimeUnit.SECONDS.sleep(2);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
	}
	
	public void start() {
		if(thread==null) {
			thread=new Thread(this);
			thread.start();
		}
	}
}


