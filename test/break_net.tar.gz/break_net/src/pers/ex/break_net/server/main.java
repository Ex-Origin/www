package pers.ex.break_net.server;
import java.io.*;

import com.google.gson.Gson;

import pers.ex.break_net.common.Func;


public class main {
	public final static int bindPort=10;
	
	public static void main(String[] args) {
		if(args.length==0) {
			System.err.println("Usage: java -jar server.jar /home/file/ip.json\n/home/file/ip.json is your granted ip");
			System.exit(0);
		}
		
		String ipPath=args[0];
		
		System.out.println(Func.getTime()+"Server start");
		
		File mapFile=new File("map.json");
		if(!mapFile.exists()) {
			System.err.println(Func.getTime()+"Can't find the file map.json");
			System.exit(1);
		}
		
		File t=new File(ipPath);
		if(!t.exists()) {
			System.err.println(Func.getTime()+"Can't find the file "+ipPath);
			System.exit(1);
		}
		
		String mapStr=Func.readToString(mapFile);
		Object[][] map= new Gson().fromJson(mapStr, Object[][].class);
		
		Server s =new Server(map,bindPort,ipPath);
		s.startListen();
		System.out.println("Server end");
	}
	
	
	
}
