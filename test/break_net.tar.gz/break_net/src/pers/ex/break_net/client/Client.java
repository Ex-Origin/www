package pers.ex.break_net.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import pers.ex.break_net.common.Func;

public class Client {
	private String serverIp;
	private int bindPort;
	public Socket server;
	public DataInputStream serverIn;
	public DataOutputStream serverOut;
	
	public ReentrantLock lock;
	
	public void getServerSocket() {
		while(true) {
			try {
				server=new Socket(serverIp,bindPort);
				serverIn= new DataInputStream(server.getInputStream());
				serverOut= new DataOutputStream(server.getOutputStream());
				server.setSoTimeout(6000);
				break;
			}catch (ConnectException e) {
			
				try {
					TimeUnit.SECONDS.sleep(6);
				} catch (InterruptedException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
			}catch (SocketException e) {
				if(e.getMessage().indexOf("Connection reset")!=-1) {
					System.err.println(Func.getTime()+"Network is unreachable (connect failed)");
				}else {
					e.printStackTrace();
				}
				
				try {
					TimeUnit.SECONDS.sleep(6);
				} catch (InterruptedException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
			}catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		System.out.println(Func.getTime()+"Connected to server:  "+server.getRemoteSocketAddress());
	}
	
	public Client(String ip,int port) {
		serverIp=ip;
		bindPort=port;
		lock=new ReentrantLock();
	}
	
	public void serverClose(){
		try {
			server.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

class Keep extends Thread{
	private Client server;
	private Thread thread;
	
	public Keep(Client c) {
		server=c;
	}
	
	public void run() {
		ReentrantLock lock=server.lock;
		while (true) {
			lock.lock();
			lock.unlock();
			
			try {
				if(server.server==null) {
					server.getServerSocket();
				}else if(server.server.isClosed()==true) {
					server.server.close();
					server.getServerSocket();
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public void start() {
		if(thread==null) {
			thread=new Thread(this);
			thread.start();
		}
	}
}