package pers.ex.break_net.client;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.concurrent.TimeUnit;

import org.omg.CORBA.portable.InputStream;

import pers.ex.break_net.common.*;

public class main {
	public final static int bindPort=10;
	public final static String succeed="my_breaksucceedmy_break";
	
	public static void main(String[] args) {
		if(args.length==0) {
			System.err.println("Usage: java -jar client.jar xxx.xxx.xxx.xxx\nxx.xxx.xxx.xxx is your server ip");
			System.exit(0);
		}
		
		String serverIp=args[0];
		
		System.out.println(Func.getTime()+"Client start");
		
		Client client = new Client(serverIp,bindPort);
		
		//client.lock.lock();
		//Keep k=new Keep(client);
		//k.start();		
		
		client.getServerSocket();
		
		byte[] buf=new byte[0x100];
		String[] s;
		String bufStr;
		int length;
		while(true) {
			try {
				if(client.serverIn==null) {
					System.out.println(Func.getTime()+"Prepare a new connection");
					client.getServerSocket();
				}
				length=client.serverIn.read(buf, 0, 0x100);
				if(length==-1) {
					System.err.println(Func.getTime()+"Disconnected from server:   "+client.server.getRemoteSocketAddress());	
					client.server.close();
					client.getServerSocket();
					continue;
				}else if(length==1 && buf[0]==22){
					client.serverOut.writeByte(33);
					continue;
				}else if(length>1) {
					;
				}else {
					System.err.println(Func.getTime()+"Disconnected from server:   "+client.server.getRemoteSocketAddress());
					client.server.close();
					client.getServerSocket();
					continue;
				}
				
				client.serverOut.write(succeed.getBytes(), 0, succeed.length());
				Socket temp = client.server;
				client.server=null;
				
				
				
//				if(client.lock.isLocked()==true) {
//					//client.lock.unlock();
//					
//					//Wait for the mutex to open
//					try {
//						TimeUnit.SECONDS.sleep(1);
//					} catch (InterruptedException ee) {
//						// TODO Auto-generated catch block
//						ee.printStackTrace();
//					}
//					//client.lock.lock();
//				}
				
				
				
				
				bufStr=new String(buf,"ASCII");
				bufStr=bufStr.replaceAll("\\x00.*\\z", "");
			 	System.out.println(Func.getTime()+"Receive a request:    "+bufStr);
				s = bufStr.split(":");
				
				Socket inner = new Socket(s[0],Integer.parseInt(s[1]));
				
				client.serverIn=null;
				client.serverOut=null;
				
				System.out.println(Func.getTime()+"Established a connection to this address:  " + bufStr);
				Connecting c = new Connecting(temp,inner);
				c.start();
				
			}catch (ConnectException e) {
				System.err.println(Func.getTime()+"There is no such port or IP, close this socket.");
				client.serverClose();
				System.err.println(Func.getTime()+"Disconnected from server:   "+client.server.getRemoteSocketAddress());
				client.getServerSocket();
				
			}catch (SocketException e) {
				if(e.getMessage().indexOf("Connection reset")==-1) {
					e.printStackTrace();
					System.out.println(Func.getTime()+"Close this software");
					System.exit(1);
				}else {
					System.out.println(Func.getTime()+ e.getMessage());
					client.serverClose();
					System.err.println(Func.getTime()+"Disconnected from server:   "+client.server.getRemoteSocketAddress());
					client.getServerSocket();
				}
				
			}catch (SocketTimeoutException e) {
				client.serverClose();
				System.err.println(Func.getTime()+"Disconnected from server:   "+client.server.getRemoteSocketAddress());
				client.getServerSocket();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (NullPointerException e) {
				try {
					TimeUnit.SECONDS.sleep(1);
				} catch (InterruptedException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
			}
			

			
			
			
		}
		
		
	}
}
