﻿#include "file.h"

unsigned int get_file_size(FILE *fp)
{

    fseek(fp, 0, SEEK_END);
    unsigned int length = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    return length;
}
