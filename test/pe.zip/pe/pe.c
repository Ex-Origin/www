﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include "pe.h"

int set_head_point(unsigned char *file, IMAGE_DOS_HEADER **dos_header, IMAGE_NT_HEADERS32 **nt_header, IMAGE_NT_HEADERS64 **nt_header64, IMAGE_SECTION_HEADER **sections, char *err_buf)
{
    *dos_header = NULL;
    *nt_header = NULL;
    *sections = NULL;
    *nt_header64 = NULL;

    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)file;
    if (dos->e_magic != 23117)
    {
        strcpy(err_buf, "该文件不是PE文件，原因：DOS头无法识别");
        return 0;
    }

    *dos_header = dos;

    IMAGE_NT_HEADERS32 *nt = (IMAGE_NT_HEADERS32 *)(file + dos->e_lfanew);

    if (nt->Signature != 17744)
    {
        strcpy(err_buf, "该文件不是PE文件，原因：NT头无法识别");
        return 0;
    }

    if (nt->FileHeader.Machine == IMAGE_FILE_MACHINE_I386)
    {
        *nt_header = nt;
        IMAGE_SECTION_HEADER *_section = (IMAGE_SECTION_HEADER *)(file + dos->e_lfanew + sizeof(IMAGE_NT_HEADERS32));
        *sections = _section;
    }
    else if (nt->FileHeader.Machine == IMAGE_FILE_MACHINE_AMD64)
    {
        *nt_header64 = (IMAGE_NT_HEADERS64 *)nt;
        IMAGE_SECTION_HEADER *_section = (IMAGE_SECTION_HEADER *)(file + dos->e_lfanew + sizeof(IMAGE_NT_HEADERS64));
        *sections = _section;
    }
    else
    {
        strcpy(err_buf, "未识别该PE程序类型");
        return 0;
    }

    return 1;
}

IMAGE_EXPORT_DIRECTORY *get_export_directory(unsigned char *file, IMAGE_NT_HEADERS32 *nt_header, unsigned int rdata_offset)
{
    //这个地址是相对与内存来说的，本程序仅仅是把分析文件，所以应该减去BaseOfCode（代码的区块的起始RVA）
    DWORD offset = nt_header->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;

    if (offset == 0)
    {
        return NULL;
    }
    offset = offset - rdata_offset;

    return (IMAGE_EXPORT_DIRECTORY *)(file + offset);
}

IMAGE_EXPORT_DIRECTORY *get_export_directory64(unsigned char *file, IMAGE_NT_HEADERS64 *nt_header, unsigned int rdata_offset)
{
    //这个地址是相对与内存来说的，本程序仅仅是把分析文件，所以应该减去BaseOfCode（代码的区块的起始RVA）
    DWORD offset = nt_header->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;

    if (offset == 0)
    {
        return NULL;
    }
    offset = offset - rdata_offset;

    return (IMAGE_EXPORT_DIRECTORY *)(file + offset);
}

unsigned int get_section_offset(IMAGE_SECTION_HEADER *sections, int section_length, char *type)
{
    //找到对应的区块
    for (int i = 0; i < section_length; i++)
    {
        if (!strcmp(sections[i].Name, type))
        {
            return sections[i].VirtualAddress - sections[i].PointerToRawData;
        }
    }

    return 0xFFFFFFFF;
}