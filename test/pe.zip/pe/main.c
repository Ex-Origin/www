﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "pe.h"
#include "file.h"

#define GAP 50

//打印所有函数的名字和入口虚拟地址
void print_all(unsigned char *pe_file, unsigned int function_number, unsigned int rdata_offset, int *name_list, DWORD *function_entry_offset_list, WORD *table_list);

void print_one(unsigned char *pe_file, unsigned int function_number, unsigned int rdata_offset, int *name_list, DWORD *function_entry_offset_list, WORD *table_list, char *str);

int main(int argc, char const *argv[])
{
    if (argc < 2)
    {
        fprintf(stderr, "用法：pe PE文件 函数～～～\n");
        exit(1);
    }
    FILE *fp = fopen(argv[1], "rb");
    if (fp == NULL)
    {
        fprintf(stderr, "Don't found the file\n");
        exit(1);
    }

    char err_buf[256] = {0};
    unsigned int length = get_file_size(fp);

    unsigned char *pe_file = (unsigned char *)malloc(length);
    fread(pe_file, 1, length, fp);

    IMAGE_DOS_HEADER *dos_header;
    IMAGE_NT_HEADERS32 *nt_header32;
    IMAGE_NT_HEADERS64 *nt_header64;
    IMAGE_SECTION_HEADER *sections;
    if (!set_head_point(pe_file, &dos_header, &nt_header32, &nt_header64, &sections, err_buf))
    {
        fprintf(stderr, "%s\n", err_buf);
        exit(1);
    }

    unsigned int rdata_offset;
    IMAGE_EXPORT_DIRECTORY *export;
    if (nt_header32 != NULL) //for x86
    {
        //导出表存在.rdata中
        int sections_length = nt_header32->FileHeader.NumberOfSections;
        rdata_offset = get_section_offset(sections, sections_length, ".rdata");

        export = get_export_directory(pe_file, nt_header32, rdata_offset);
    }
    else if (nt_header64 != NULL) //for x64
    {
        //导出表存在.rdata中
        int sections_length = nt_header64->FileHeader.NumberOfSections;
        rdata_offset = get_section_offset(sections, sections_length, ".rdata");

        export = get_export_directory64(pe_file, nt_header64, rdata_offset);
    }

    if (rdata_offset == 0xFFFFFFFF)
    {
        fprintf(stderr, "找不到.rdata区块\n");
        exit(1);
    }

    if (export == NULL)
    {
        fprintf(stderr, "该PE程序没有导出表，可能只是一个可执行程序\n");
        exit(1);
    }

    //总共的函数数量
    unsigned int function_number = export->NumberOfFunctions;

    //同理，也在.rdata中
    unsigned int offset = export->AddressOfNames - rdata_offset;

    //存放AddressOfNames列表
    int *name_list = (int *)(pe_file + offset);

    offset = export->AddressOfNameOrdinals - rdata_offset;
    WORD *table_list = (WORD *)(pe_file + offset);

    offset = export->AddressOfFunctions - rdata_offset;
    DWORD *function_entry_offset_list = (DWORD *)(pe_file + offset);

    if (argc > 2)
    {
        for (int i = 2; i < argc; i++)
        {
            print_one(pe_file, function_number, rdata_offset, name_list, function_entry_offset_list, table_list, (char *)argv[i]);
        }
    }
    else
    {
        print_all(pe_file, function_number, rdata_offset, name_list, function_entry_offset_list, table_list);
    }

    return 0;
}

void print_all(unsigned char *pe_file, unsigned int function_number, unsigned int rdata_offset, int *name_list, DWORD *function_entry_offset_list, WORD *table_list)
{
    //仅仅为了美观。
    char space[GAP];
    memset(space, ' ', GAP);

    for (int i = 0; i < function_number; i++)
    {
        char *function_name = pe_file + name_list[i] - rdata_offset;
        int function_name_length = strlen(function_name);
        int gap = GAP - function_name_length;
        space[gap] = '\0';

        unsigned int RVA_entry = function_entry_offset_list[table_list[i]];

        printf("%s%s%08X    %8u\n", function_name, space, RVA_entry, RVA_entry);
        space[gap] = ' ';
    }
}

void print_one(unsigned char *pe_file, unsigned int function_number, unsigned int rdata_offset, int *name_list, DWORD *function_entry_offset_list, WORD *table_list, char *str)
{
    //仅仅为了美观。
    char space[GAP];
    memset(space, ' ', GAP);

    for (int i = 0; i < function_number; i++)
    {
        char *function_name = pe_file + name_list[i] - rdata_offset;
        if (!strcmp(str, function_name))
        {
            int function_name_length = strlen(function_name);
            int gap = GAP - function_name_length;
            space[gap] = '\0';

            unsigned int RVA_entry = function_entry_offset_list[table_list[i]];

            printf("%s%s%08X    %8u\n", function_name, space, RVA_entry, RVA_entry);
            return;
        }
    }

    puts("");
}