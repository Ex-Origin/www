﻿#pragma once

#ifdef _WIN32
#include <windows.h>
#endif

#ifdef __GNUC__
#define IMAGE_NUMBEROF_DIRECTORY_ENTRIES 16
#define IMAGE_DIRECTORY_ENTRY_EXPORT 0
#define IMAGE_DIRECTORY_ENTRY_IMPORT 1
#define IMAGE_DIRECTORY_ENTRY_RESOURCE 2
#define IMAGE_DIRECTORY_ENTRY_EXCEPTION 3
#define IMAGE_DIRECTORY_ENTRY_SECURITY 4
#define IMAGE_DIRECTORY_ENTRY_BASERELOC 5
#define IMAGE_DIRECTORY_ENTRY_DEBUG 6
#define IMAGE_DIRECTORY_ENTRY_COPYRIGHT 7
#define IMAGE_DIRECTORY_ENTRY_ARCHITECTURE 7
#define IMAGE_DIRECTORY_ENTRY_GLOBALPTR 8
#define IMAGE_DIRECTORY_ENTRY_TLS 9
#define IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG 10
#define IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT 11
#define IMAGE_DIRECTORY_ENTRY_IAT 12
#define IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT 13
#define IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR 14

#define IMAGE_SIZEOF_SHORT_NAME 8

typedef unsigned short WORD;
typedef int LONG;
typedef unsigned int DWORD;
typedef unsigned char BYTE;
typedef unsigned long long ULONGLONG;

typedef struct _IMAGE_SECTION_HEADER
{
	BYTE Name[IMAGE_SIZEOF_SHORT_NAME]; // 节表名称,如“.text”
	//IMAGE_SIZEOF_SHORT_NAME=8
	union {
		DWORD PhysicalAddress; // 物理地址
		DWORD VirtualSize;	 // 真实长度，这两个值是一个联合结构，可以使用其中的任何一个，一
							   // 般是取后一个
	} Misc;

	DWORD VirtualAddress;		// 节区的 RVA 地址
	DWORD SizeOfRawData;		// 在文件中对齐后的尺寸
	DWORD PointerToRawData;		// 在文件中的偏移量
	DWORD PointerToRelocations; // 在OBJ文件中使用，重定位的偏移
	DWORD PointerToLinenumbers; // 行号表的偏移（供调试使用地）
	WORD NumberOfRelocations;   // 在OBJ文件中使用，重定位项数目
	WORD NumberOfLinenumbers;   // 行号表中行号的数目
	DWORD Characteristics;		// 节属性如可读，可写，可执行等
} IMAGE_SECTION_HEADER, *PIMAGE_SECTION_HEADER;

typedef struct _IMAGE_EXPORT_DIRECTORY
{
	DWORD Characteristics;   //现在没有用到，一般为0。
	DWORD TimeDateStamp;	 //导出表生成的时间戳，由连接器生成
	WORD MajorVersion;		 //看名字是版本，实际貌似没有用，都是0。
	WORD MinorVersion;		 //
	DWORD Name;				 //模块的名字。
	DWORD Base;				 //序号的基数，按序号导出函数的序号值从Base开始递增。
	DWORD NumberOfFunctions; //所有导出函数的数量。
	DWORD NumberOfNames;	 //按名字导出函数的数量。

	// 一个RVA，指向一个DWORD数组，数组中的每一项是一个导出函数的RVA，顺序与导出序号相同。
	DWORD AddressOfFunctions; // RVA from base of image

	//一个RVA，依然指向一个DWORD数组，数组中的每一项仍然是一个RVA，指向一个表示函数名字。
	DWORD AddressOfNames; // RVA from base of image

	//一个RVA，还是指向一个WORD数组，数组中的每一项与AddressOfNames中的每一项对应，表示该名字的函数在AddressOfFunctions中的序号。
	DWORD AddressOfNameOrdinals; // RVA from base of image
} IMAGE_EXPORT_DIRECTORY, *PIMAGE_EXPORT_DIRECTORY;

//DOS头的结构体 64Bytes
typedef struct _IMAGE_DOS_HEADER
{
	WORD e_magic;	//魔术数字，所有MS-DOS兼容的可执行文件都将此值设为0X4D5A(MZ) 默认23117
	WORD e_cblp;	 //文件最后页的字节数
	WORD e_cp;		 //文件页数
	WORD e_crlc;	 //重定义元素个数
	WORD e_cparhdr;  //头部尺寸，以段落为单位
	WORD e_minalloc; //所需的最小附加段
	WORD e_maxalloc; //所需的最大附加段
	WORD e_ss;		 //初始的SS值(相对偏移量)
	WORD e_sp;		 //初始的SP值
	WORD e_csum;	 //校验和
	WORD e_ip;		 //初始的IP值
	WORD e_cs;		 //初始的CS值(相对偏移量)
	WORD e_lfarlc;   //重分配表文件地址
	WORD e_ovno;	 //覆盖号
	WORD e_res[4];   //保留字
	WORD e_oemid;	//OEM标识符(相对e_oeminfo)
	WORD e_oeminfo;  //OEM信息
	WORD e_res2[10]; //保留字
	DWORD e_lfanew;  //新exe头部的文件地址
} IMAGE_DOS_HEADER, *PIMAGE_DOS_HEADER;

#define IMAGE_FILE_MACHINE_I386 0x014c  //332     x86
#define IMAGE_FILE_MACHINE_AMD64 0x8664 //34404	     x64

//20 bytes PE文件物理分布的信息
typedef struct _IMAGE_FILE_HEADER
{
	WORD Machine;

	WORD NumberOfSections;
	DWORD TimeDateStamp;
	DWORD PointerToSymbolTable;
	DWORD NumberOfSymbols;
	WORD SizeOfOptionalHeader;
	WORD Characteristics;
} IMAGE_FILE_HEADER, *PIMAGE_FILE_HEADER;

typedef struct _IMAGE_DATA_DIRECTORY
{
	DWORD VirtualAddress;
	DWORD Size;
} IMAGE_DATA_DIRECTORY, *PIMAGE_DATA_DIRECTORY;

typedef struct _IMAGE_OPTIONAL_HEADER
{
	//
	// Standard fields.  56 Bytes
	//
	WORD Magic;					   // 标志字, ROM 映像（0107h）,普通可执行文件（010Bh）
	BYTE MajorLinkerVersion;	   // 链接程序的主版本号
	BYTE MinorLinkerVersion;	   // 链接程序的次版本号
	DWORD SizeOfCode;			   // 所有含代码的节的总大小
	DWORD SizeOfInitializedData;   // 所有含已初始化数据的节的总大小
	DWORD SizeOfUninitializedData; // 所有含未初始化数据的节的大小
	DWORD AddressOfEntryPoint;	 // 程序执行入口RVA
	DWORD BaseOfCode;			   // 代码的区块的起始RVA。
	DWORD BaseOfData;			   // 数据的区块的起始RVA。。
	//
	// NT additional fields.    以下是属于NT结构增加的领域。
	//
	DWORD ImageBase;				  // 程序的首选装载地址
	DWORD SectionAlignment;			  // 内存中的区块的对齐大小。
	DWORD FileAlignment;			  // 文件中的区块的对齐大小。
	WORD MajorOperatingSystemVersion; // 要求操作系统最低版本号的主版本号
	WORD MinorOperatingSystemVersion; // 要求操作系统最低版本号的副版本号
	WORD MajorImageVersion;			  // 可运行于操作系统的主版本号
	WORD MinorImageVersion;			  // 可运行于操作系统的次版本号
	WORD MajorSubsystemVersion;		  // 要求最低子系统版本的主版本号
	WORD MinorSubsystemVersion;		  // 要求最低子系统版本的次版本号
	DWORD Win32VersionValue;		  // 莫须有字段，不被病毒利用的话一般为0
	DWORD SizeOfImage;				  // 映像装入内存后的总尺寸
	DWORD SizeOfHeaders;			  // 所有头+ 区块表的尺寸大小
	DWORD CheckSum;					  // 映像的校检和
	WORD Subsystem;					  // 可执行文件期望的子系统
	WORD DllCharacteristics;		  // DllMain()函数何时被调用，默认为0
	DWORD SizeOfStackReserve;		  // 初始化时的栈大小
	DWORD SizeOfStackCommit;		  // 初始化时实际提交的栈大小
	DWORD SizeOfHeapReserve;		  // 初始化时保留的堆大小
	DWORD SizeOfHeapCommit;			  // 初始化时实际提交的堆大小
	DWORD LoaderFlags;				  // 与调试有关，默认为0
	DWORD NumberOfRvaAndSizes;		  // 下边数据目录的项数，这个字段自Windows NT 发布以来        // 一直是16
	IMAGE_DATA_DIRECTORY DataDirectory[IMAGE_NUMBEROF_DIRECTORY_ENTRIES];
	// 数据目录表
} IMAGE_OPTIONAL_HEADER32, *PIMAGE_OPTIONAL_HEADER32;

typedef struct _IMAGE_OPTIONAL_HEADER64
{
	WORD Magic;
	BYTE MajorLinkerVersion;
	BYTE MinorLinkerVersion;
	DWORD SizeOfCode;
	DWORD SizeOfInitializedData;
	DWORD SizeOfUninitializedData;
	DWORD AddressOfEntryPoint;
	DWORD BaseOfCode;
	ULONGLONG ImageBase;
	DWORD SectionAlignment;
	DWORD FileAlignment;
	WORD MajorOperatingSystemVersion;
	WORD MinorOperatingSystemVersion;
	WORD MajorImageVersion;
	WORD MinorImageVersion;
	WORD MajorSubsystemVersion;
	WORD MinorSubsystemVersion;
	DWORD Win32VersionValue;
	DWORD SizeOfImage;
	DWORD SizeOfHeaders;
	DWORD CheckSum;
	WORD Subsystem;
	WORD DllCharacteristics;
	ULONGLONG SizeOfStackReserve;
	ULONGLONG SizeOfStackCommit;
	ULONGLONG SizeOfHeapReserve;
	ULONGLONG SizeOfHeapCommit;
	DWORD LoaderFlags;
	DWORD NumberOfRvaAndSizes;
	IMAGE_DATA_DIRECTORY DataDirectory[IMAGE_NUMBEROF_DIRECTORY_ENTRIES];
} IMAGE_OPTIONAL_HEADER64, *PIMAGE_OPTIONAL_HEADER64;

//PE头结构 248 Bytes
typedef struct _IMAGE_NT_HEADERS
{
	DWORD Signature;						//4 bytes PE文件头标志：(e_lfanew)->‘PE’ 默认17744
	IMAGE_FILE_HEADER FileHeader;			//20 bytes PE文件物理分布的信息
	IMAGE_OPTIONAL_HEADER32 OptionalHeader; //224 bytes PE文件逻辑分布的信息
} IMAGE_NT_HEADERS32, *PIMAGE_NT_HEADERS32;

//64位PE头结构 264 Bytes
typedef struct _IMAGE_NT_HEADERS64
{
	DWORD Signature;						//4 bytes PE文件头标志：(e_lfanew)->‘PE’ 默认17744
	IMAGE_FILE_HEADER FileHeader;			//20 bytes PE文件物理分布的信息
	IMAGE_OPTIONAL_HEADER64 OptionalHeader; //240 bytes PE文件逻辑分布的信息
} IMAGE_NT_HEADERS64, *PIMAGE_NT_HEADERS64;

//用于判断是多少位的机器
typedef struct _IMAGE_NT_HEADERS_WITHOUT_OPTIONSALHEADER
{
	DWORD Signature;						//4 bytes PE文件头标志：(e_lfanew)->‘PE’ 默认17744
	IMAGE_FILE_HEADER FileHeader;			//20 bytes PE文件物理分布的信息
	IMAGE_OPTIONAL_HEADER64 OptionalHeader; //240 bytes PE文件逻辑分布的信息
} IMAGE_NT_HEADERS_NO_OPTION;
#endif

//执行成功返回1，失败返回0
//err_buf返回失败的原因
int set_head_point(unsigned char *file, IMAGE_DOS_HEADER **dos_header, IMAGE_NT_HEADERS32 **nt_header, IMAGE_NT_HEADERS64 **nt_header64, IMAGE_SECTION_HEADER **sections, char *err_buf);

//返回的指针并不是新的内存空间，任然是指向的file内存块
//如果没有导出表，则返回NULL
IMAGE_EXPORT_DIRECTORY *get_export_directory(unsigned char *file, IMAGE_NT_HEADERS32 *nt_header, unsigned int rdata_offset);
IMAGE_EXPORT_DIRECTORY *get_export_directory64(unsigned char *file, IMAGE_NT_HEADERS64 *nt_header, unsigned int rdata_offset);

//返回内存和文件位置的相对偏移
unsigned int get_section_offset(IMAGE_SECTION_HEADER *sections, int section_length, char *type);