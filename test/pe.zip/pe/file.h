﻿#pragma once
#include <stdio.h>

//返回文件大小
//注：使用函数后文件指针将会指向文件开头
unsigned int get_file_size(FILE *fp);