/*
Author:				Ex
Create time:		2018-05-19
last modification:	2018-05-28
*/
#define _CRT_SECURE_NO_WARNINGS
#ifndef EX_NET
#define EX_NET
#include<pcap.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#define ETHERTYPE_IP 0x0800   //IP Protocal  
#define ETHERTYPE_ARP 0x0806   //Address Resolution Protocal  
#define ETHERTYPE_REVARP 0x0835   //Reverse Address Resolution Protocal
#define ANY 1

#ifndef WIN32
struct sockaddr
{
	unsigned short sa_family;
	unsigned char sa_data[14];
};

#else

#include <IPHlpApi.h>
#pragma comment(lib,"IPHlpApi.lib")
int get_adapter(PIP_ADAPTER_INFO *adapter);
#endif // !WIN32

typedef struct my_own_addr
{
	unsigned char ip[4];
	unsigned char mask[4];
	unsigned char broadaddr[4];
	char name[60];
	char description[60];
}my_single_addr;

typedef struct my_addr
{
	int length;
	my_single_addr addr[ANY];
}my_addr;

typedef struct my_own_adapter
{
	unsigned char ip[4];
	unsigned char ip_mac[6];
	unsigned char gateway[4];
	unsigned char gateway_mac[6];
	unsigned char mask[4];
	char description[60];
}my_single_adapter;

typedef struct my_adapter
{
	int length;
	my_single_adapter adapter[ANY];
}my_adapter;



typedef struct my_own_ethernet_hear //14 bits 
{
	unsigned char dhost[6]; //MAC address of destination
	unsigned char shost[6]; //Mac address of source
	unsigned short r_type; //protocol type
}my_ether_header;

/*For example
*(unsigned short *)send_arp.arp.r_hardware_type = reverse_short(0x0001);
*(unsigned short *)send_arp.arp.r_protocol_type = reverse_short(0x0800);
send_arp.arp.mac_length = 6;
send_arp.arp.ip_length = 4;
*(unsigned short *)send_arp.arp.r_operating_mode = reverse_short(0x0001);
*(unsigned int *)(send_arp.arp.source_ip) = reverse_int(0xC0A80101);
*(unsigned int *)(send_arp.arp.destination_ip) = reverse_int(0xC0A80101);
*/
typedef struct ARP_header //28 bits
{
	unsigned char r_hardware_type[2]; //Hardware types��it is ARPHRD_EHER in ethernet
	unsigned char r_protocol_type[2]; //Protocol type 
	unsigned char mac_length; //Length of MAC address
	unsigned char ip_length; //Length of IP address
	//Operating mode,ARP request is 0x0001;ARP response is 0x0002
	unsigned char r_operating_mode[2]; //RARP request is 0x0003;RARP response is 0x0004
	unsigned char source_mac[6]; //
	unsigned char source_ip[4]; //
	unsigned char destination_mac[6]; //
	unsigned char destination_ip[4]; //
}ARP_header;

/*For example
send.ip.version_and_header_length = 0x45;
send.ip.type_of_service = 0x00;
*(unsigned short *)send.ip.r_length = reverse_short(0x0028);
*(unsigned short *)send.ip.r_identification = reverse_short(0x4568);//There need reverse
*(unsigned short *)send.ip.r_flags_offset = reverse_short(0x4000);
send.ip.time_to_live = 64;
send.ip.protocol = 6;
*(unsigned short *)send.ip.r_header_checksum = reverse_short(0x7881);
*(undigned int *)send.ip.destination = reverse_int(0xC0A80101);
*(unsigned int *)send.ip.destination = reverse_int(0xC0A80101);
*/
typedef struct my_ipv4_header //IP header
{
	//version 4 bits + header length 4 bits
	unsigned char version_and_header_length;

	unsigned char type_of_service; //type of service:TOS
	unsigned char r_length[2];//Total length of datagram
	//Here we need to reverse
	unsigned char r_identification[2];

	//flags : 3 bits + offset : 13 bits
	//You need to calculate for yourself
	unsigned char r_flags_offset[2];//Number of deviation

	unsigned char time_to_live; //time to live
	//Used to distinguish the upper layer protocols
	//ICMP is 1 ; TCP is 6 ; UDP is 7
	unsigned char protocol; //
	unsigned char r_header_checksum[2]; //header 
	unsigned char source[4]; //
	unsigned char destination[4]; //
}my_ip_header;

/*For example
*(unsigned short *)send.tcp.r_source_port = reverse_short(32308);
*(unsigned short *)send.tcp.r_destination_port = reverse_short(443);//port;
*(unsigned int *)send.tcp.r_sequence_number = reverse_int(0x4510FB9);
*(unsigned int *)send.tcp.r_acknowledge_number = reverse_int(0x17CEC553);
*(unsigned short *)send.tcp.data_offset_and_flags = reverse_short(0x5010);
*(unsigned short *)send.tcp.r_windows = reverse_short(66);
*(unsigned short *)send.tcp.r_checksum = reverse_short(0xC190);
*(unsigned short *)send.tcp.r_urgent_pointer = reverse_short(NULL);
*/
typedef struct TCP_header //20bits
{
	unsigned char r_source_port[2]; //
	unsigned char r_destination_port[2];//
	unsigned char r_sequence_number[4]; //
	unsigned char r_acknowledge_number[4];//

	//data offset:	4 bits
	//keep_field:	3 bits
	//current:		1 bit
	//CWR :			1 bit
	//ECN_Echo :	1 bit
	//URG :			1 bit
	//ACK :			1 bit
	//PSH :			1 bit
	//RST :			1 bit
	//SYN :			1 bit
	//FIN :			1 bit
	unsigned char data_offset_and_flags[2];

	unsigned char r_windows[2]; //
	unsigned char r_checksum[2]; //
	unsigned char r_urgent_pointer[2]; //
}my_tcp_header;

typedef struct my_own_ARP_packet
{
	my_ether_header ether;
	ARP_header arp;
}ARP_packet;

typedef struct my_own_tcp_packet
{
	my_ether_header ether;
	my_ip_header ip;
	my_tcp_header tcp;
}TCP_packet;

void print_net(void *net, int times);

void print_net_normal(void *net, int times);

//ethernet type
unsigned short reverse_short(unsigned short str);
unsigned int reverse_int(unsigned int str);

int get_all_addr(my_addr **addrs, char errbuf[]);
int get_all_adapter(my_adapter **all_adapter);

int count_pcap_if_t(pcap_if_t *all_dev);

//converts string to IP
//space is obtained from the heap
int str_to_ip(char str[]);

int is_same_network(unsigned char *ip1, unsigned char *ip2, unsigned char *mask);

int use_ip_get_mac(pcap_t *handle, unsigned char your_ip[], unsigned char your_mac[], unsigned char want_ip[], unsigned char want_mac[]);

unsigned short calculate_checksum(unsigned short hand[], unsigned short type);

#endif // !EX_NET
