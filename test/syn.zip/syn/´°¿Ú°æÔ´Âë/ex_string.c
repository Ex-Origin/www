#include"ex_string.h"

int str_to_int(char *str)
{
	int num=0;
	int sign=1;
	if (*str == '-')
	{
		sign = -1;
		str++;
	}

	while (*str >= '0'&&*str <= '9')
	{
		num = num * 10 + *str - '0';
		str++;
	}

	return num*sign;
}