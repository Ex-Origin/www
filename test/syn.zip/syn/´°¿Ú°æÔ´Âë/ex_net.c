#include"ex_net.h"
#include"ex_string.h"

#include<stdio.h>
#include<malloc.h>
#include<pcap.h>
#define AF_INET 2

void print_net(void *net,int times)
{
	unsigned char *str = (unsigned char *)net;
	int t = times - 1;
	int i;
	for (i = 0; i < t; i++)
	{
		printf("%02X-", *str++);
	}
	printf("%02X\n", *str++);
}

int count_pcap_if_t(pcap_if_t *all_dev)
{
	int amount = 0;
	while (all_dev!=NULL)
	{
		amount++;
		all_dev = all_dev->next;
	}
	return amount;
}

void print_net_normal(void *net, int times)
{
	unsigned char *str = (unsigned char *)net;
	int t = times - 1;
	int i;
	for (i = 0; i < t; i++)
	{
		printf("%d.", *str++);
	}
	printf("%d\n", *str++);
}

unsigned short reverse_short(unsigned short str)
{
	unsigned short type;
	*(unsigned char *)&type = *(((unsigned char *)&str) + 1);
	*(((unsigned char *)&type) + 1) = *(unsigned char *)&str;
	return type;
}

unsigned int reverse_int(unsigned int str)
{
	unsigned int type;
	*(unsigned char *)&type = *(((unsigned char *)&str) + 3);
	*(((unsigned char *)&type) + 1) = *(((unsigned char *)&str) + 2);
	*(((unsigned char *)&type) + 2) = *(((unsigned char *)&str) + 1);
	*(((unsigned char *)&type) + 3) = *(unsigned char *)&str;
	return type;
}

int get_all_addr(my_addr **addrs,char errbuf[])
{
	pcap_if_t *all_dev = NULL;
	if (pcap_findalldevs(&all_dev, errbuf) == -1)
	{
		fprintf(stderr, errbuf);
		return -1;
	}
	int amount = count_pcap_if_t(all_dev);
	pcap_if_t *dev = all_dev;

	int i;
	if (dev == NULL)
	{
		return -1;
	}
	*addrs = (my_addr *)malloc(sizeof(my_addr)+sizeof(my_single_addr)*(amount-1));
	(*addrs)->length = amount;

	for (i = 0;i < amount;i++)
	{
		int key = 1;
		struct pcap_addr *t = dev->addresses;
		while (t->addr->sa_family != AF_INET)
		{
			if (t->next == NULL)
			{
				amount--;
				i--;
				(*addrs)->length = amount;
				key = 0;
				break;
			}
			t = t->next;
		}

		if (key)
		{
			*(int *)((*addrs)->addr[i].ip) = *(int *)((unsigned char *)(t->addr->sa_data) + 2);
			*(int *)((*addrs)->addr[i].mask) = *(int *)((unsigned char *)(t->netmask->sa_data) + 2);
			*(int *)((*addrs)->addr[i].broadaddr) = *(int *)((unsigned char *)(t->broadaddr->sa_data) + 2);
			strcpy((*addrs)->addr[i].name, dev->name);
			strcpy((*addrs)->addr[i].description, dev->description);
		}
		


		dev = dev->next;
	}

	pcap_freealldevs(all_dev);
	
	return 0;
}




int str_to_ip(char str[])
{
	unsigned char ip[4];

	*ip = str_to_int(str);
	int i;
	for (i = 1;i < 4;i++)
	{
		while (*str >= '0'&&*str <= '9')
		{
			str++;
		}
		str++;
		ip[i] = str_to_int(str);
	}

	return *(int *)ip;
}

int is_same_network(unsigned char *ip1, unsigned char *ip2, unsigned char *mask)
{
	unsigned int int_ip1 =*(unsigned int *)ip1;
	unsigned int int_ip2 = *(unsigned int *)ip2;
	unsigned int int_mask = *(unsigned int *)mask;

	int i;
	for(i=0;i<32;i++)
	{
		if((int_mask&1) && ((int_ip1&1)!=(int_ip2&1)))
		{
			return -1;
		}
		int_mask>>=1;
		int_ip1>>=1;
		int_ip2>>=1;
	}

	return 0;
}


int use_ip_get_mac(pcap_t *handle, unsigned char your_ip[], unsigned char your_mac[], unsigned char want_ip[], unsigned char want_mac[])
{
	ARP_packet send_arp = { 0 };

	//for ethernet header
	//set the destination as FF-FF-FF-FF-FF-FF
	int i;
	for (i = 0;i < 6;i++)
	{
		send_arp.ether.dhost[i] = 0xFF;
		send_arp.ether.shost[i] = your_mac[i];
		send_arp.arp.source_mac[i] = your_mac[i];
		send_arp.arp.destination_mac[i] = 0x00;
	}
	send_arp.ether.r_type = reverse_short(ETHERTYPE_ARP);

	//for arp header
	//set hardware type as ethernet type
	*(unsigned short *)send_arp.arp.r_hardware_type = reverse_short(0x0001);
	//Here use IpV4 protocol
	*(unsigned short *)send_arp.arp.r_protocol_type = reverse_short(ETHERTYPE_IP);
	send_arp.arp.mac_length = 6;
	send_arp.arp.ip_length = 4;
	*(unsigned short *)send_arp.arp.r_operating_mode = reverse_short(0x0001);
	*(int *)(send_arp.arp.source_ip) = *(int *)your_ip;
	*(int *)(send_arp.arp.destination_ip) = *(int *)(want_ip);

	struct pcap_pkthdr pkt_header;
	//int l = sizeof(send_arp);

	if (pcap_sendpacket(handle, (unsigned char *)&send_arp, sizeof(ARP_packet)) != 0)
	{
		fprintf(stderr, "\nError sending the packet: \n", pcap_geterr(handle));
		return -1;
	}
	ARP_packet *response;
	for (i = 0;i < 10000;i++)
	{
		response = (ARP_packet *)pcap_next(handle, &pkt_header);
		if (response != NULL && *(int*)(response->arp.source_ip) == *(int *)want_ip)
		{
			int ii;
			for (ii = 0; ii < 6; ii++)
			{
				want_mac[ii] = response->arp.source_mac[ii];
			}
			break;
		}
	}
	
	


	return 0;
}

unsigned short calculate_checksum(unsigned short hand[], unsigned short type)
{
	int sum = 0;
	int i;

	switch (type)
	{
	case 0x0800:
		//filter ethernet header
		hand += 14 / 2;
		
		for (i = 0;i < 10;i++)
		{
			sum += reverse_short(hand[i]);
			//printf("%04X\n",reverse_short( hand[i]));
		}
		break;
	case 0x0006:
		hand += 26 / 2;

		for (i = 0;i < 14;i++)
		{
			sum += reverse_short(hand[i]);
		}
		sum += (6 + 20);
		break;
	default:
		break;
	}

	unsigned short *temp = (unsigned short *)&sum + 1;
	sum += *temp;
	return (unsigned short)~sum;
	
}

#ifdef WIN32
int get_all_adapter(my_adapter **all_adapter)
{
	IP_ADAPTER_INFO *system_all_adapter = NULL;
	IP_ADAPTER_INFO *temp = NULL;


	unsigned int ulSize = sizeof(IP_ADAPTER_INFO);
	system_all_adapter = (PIP_ADAPTER_INFO)malloc(ulSize);
	int nRet = GetAdaptersInfo(system_all_adapter, &ulSize);

	if (ERROR_BUFFER_OVERFLOW == nRet)
	{
		free(system_all_adapter);

		system_all_adapter = (PIP_ADAPTER_INFO)malloc(ulSize);

		nRet = GetAdaptersInfo(system_all_adapter, &ulSize);

		if (ERROR_SUCCESS != nRet)
		{
			if (system_all_adapter != NULL)
			{
				free(system_all_adapter);
			}
			fprintf(stderr, "Failed to get the system network card information\n");
			return -1;
		}
	}

	temp = system_all_adapter;
	int length = 0;

	while (temp != NULL)
	{
		length++;
		temp = temp->Next;
	}

	(*all_adapter) = (my_adapter *)malloc(sizeof(my_adapter) + sizeof(my_single_adapter)*(length - 1));
	(*all_adapter)->length = length;

	temp = system_all_adapter;
	int i;
	for (i = 0;i < length;i++)
	{
		*(int *)(*all_adapter)->adapter[i].ip = str_to_ip(temp->IpAddressList.IpAddress.String);
		int j;
		for (j = 0;j < 6;j++)
		{
			(*all_adapter)->adapter[i].ip_mac[j] = temp->Address[j];
		}

		*(int *)(*all_adapter)->adapter[i].gateway = str_to_ip(temp->GatewayList.IpAddress.String);
		strcpy((*all_adapter)->adapter[i].description, temp->Description);
		*(int *)(*all_adapter)->adapter[i].mask = str_to_ip(temp->IpAddressList.IpMask.String);

		temp = temp->Next;
	}

	free(system_all_adapter);
	system_all_adapter = NULL;
	temp = NULL;

	return 0;
}
#endif // WIN32
