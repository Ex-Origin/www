/*
Author:				Ex
Create time:		2018-05-19
last modification:	2018-05-28
*/
#ifndef EX_FUNC
#define EX_FUNC
#include"ex_net.h"

int get_my_addr(my_single_addr **address,char errbuf[],unsigned char *d_attack_ip);
int get_my_adapter(my_single_adapter **adapter,unsigned char *d_attack_ip);

void attack(pcap_t *handle, unsigned char your_ip[], unsigned char attack_ip[], unsigned char mac[], unsigned short port);

#endif // !EX_FUNC

