/*
Author:				Ex
Create time:		2018-05-20
last modification:	none
*/

#ifndef MY_STRING
#define MY_STRING

int str_to_int(char *str);
#endif // !MY_STRING

